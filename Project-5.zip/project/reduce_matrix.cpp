   #include <stdio.h>
   #include <unistd.h>
   #include <cstdlib>
   #include <mpi.h>
#include <math.h>
   
   using namespace std;
   
   int main(int argc,char *argv[])
   {
     int root = 0,numprocs,rank,index;
     int no_interval;
     int destination,source;
     int dest_tag,source_tag;
     int iproc,interval;
	float t1,t2,t3;
     double my_pi,pi = 0.0,sum = 0.0,x = 0.0,h;
    
     MPI_Status status;
  struct timeval start, end;
  char hostname[256];
  int hostname_len;
     
   /* ..... MPI Intializing ......*/
 
     MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
  MPI_Get_processor_name(hostname,&hostname_len);
gettimeofday(&start,NULL);
  
int input[numprocs];
int numrow = 3;
int data;

if(rank%numrow==0 || rank%numrow==1)
{
	my_pi = rank+1;
         pi = pi + my_pi;
         if(rank+1 < numprocs){
	MPI_Recv(&my_pi, 1, MPI_DOUBLE, rank+1, 1, MPI_COMM_WORLD, &status); 
	   pi=pi+my_pi;}
	if(rank+3 < numprocs && rank%numrow==0){
	MPI_Recv(&my_pi, 1, MPI_DOUBLE, rank+3, 1, MPI_COMM_WORLD, &status); 
           pi = pi + my_pi;}
	if(rank%numrow==0)
	MPI_Send(&pi, 1, MPI_DOUBLE, (rank-3), 1, MPI_COMM_WORLD);
	else
	MPI_Send(&pi, 1, MPI_DOUBLE, (rank-1), 1, MPI_COMM_WORLD);
printf("%s\t",hostname);
		printf("%f ",pi);
printf("\n");
}
else{
	my_pi = rank+1;
	MPI_Send(&my_pi, 1, MPI_DOUBLE, (rank-1), 1, MPI_COMM_WORLD);

printf("%s\t",hostname);
		printf("%f ",my_pi);
printf("\n");
    }   
 
      if(rank == root)
   printf(" \nValue of sum is :: %f\n",pi);

 



if(rank==0)
	printf("%f\n",pi);
gettimeofday(&end,NULL); 
 
  	printf("%s\t%10.10f\n",hostname,( end.tv_usec  - start.tv_usec) / 1000000.0);

    /*.......Fianlizing MPI.......*/ 
  MPI_Finalize();
     return 0;
  }
 

