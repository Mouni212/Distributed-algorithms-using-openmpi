   #include <stdio.h>
   #include <unistd.h>
   #include <cstdlib>
   #include <mpi.h>
   
   using namespace std;
   
   int main(int argc,char *argv[])
   {
     int root = 0,numprocs,rank,index;
     int no_interval;
     int destination,source;
     int dest_tag,source_tag;
     int iproc,interval;
	float t1,t2,t3;
     double my_pi,pi = 0.0,sum = 0.0,x = 0.0,h;
    
     MPI_Status status;
  struct timeval start, end;
  char hostname[256];
  int hostname_len;
     
   /* ..... MPI Intializing ......*/
 
     MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
  MPI_Get_processor_name(hostname,&hostname_len);
gettimeofday(&start,NULL);
  
int output[numprocs];
int numrow = 3;
int data,buffer;

if(rank == 0){
	output[0]=rank+1;
	for(int i=1;i<numrow;i++){
		MPI_Recv(&buffer, 1, MPI_DOUBLE, rank+1, 1, MPI_COMM_WORLD, &status);
		printf("side0 : %s %d\n",hostname,buffer);
		output[i] = buffer;
	}
	for(int i=numrow;i<numprocs;i++){
		if(rank+numrow < numprocs){
			MPI_Recv(&buffer, 1, MPI_DOUBLE, rank+numrow, 1, MPI_COMM_WORLD, &status);
			printf("bottom0 : %s %d\n",hostname,buffer);
			output[i] = buffer;
		}
	}
}
else if(rank%numrow == 0){
	buffer = rank+1;
	MPI_Send(&buffer, 1, MPI_DOUBLE, (rank-numrow), 1, MPI_COMM_WORLD);
	int itr = (numrow-(rank/numrow));
	int p = numrow-1;
	//printf("%s %d %d\n",hostname,rank,numrow);
	for(int i=1;i<numrow;i++){
		MPI_Recv(&buffer, 1, MPI_DOUBLE, rank+1, 1, MPI_COMM_WORLD, &status);
		MPI_Send(&buffer, 1, MPI_DOUBLE, (rank-numrow), 1, MPI_COMM_WORLD);
		printf("side : %s %d\n",hostname,buffer);
		output[i] = buffer;
	}
	for(int i=0;i<(p+1)*(itr-1);i++){
		if(rank+numrow < numprocs){
			MPI_Recv(&buffer, 1, MPI_DOUBLE, rank+numrow, 1, MPI_COMM_WORLD, &status); 
			MPI_Send(&buffer, 1, MPI_DOUBLE, (rank-numrow), 1, MPI_COMM_WORLD);
			printf("bottom : %s %d\n",hostname,buffer);
		}
	}
}
else
{
        buffer = rank+1;
	MPI_Send(&buffer, 1, MPI_DOUBLE, (rank-1), 1, MPI_COMM_WORLD);
	int itr = (numrow-rank%numrow);
	if(rank+1 < numprocs){
		for(int i=0;i<itr-1;i++){
			MPI_Recv(&buffer, 1, MPI_DOUBLE, rank+1, 1, MPI_COMM_WORLD, &status); 
			MPI_Send(&buffer, 1, MPI_DOUBLE, (rank-1), 1, MPI_COMM_WORLD);
			printf("%s %d\n",hostname,buffer);
		}
	}		
}   
 
  //    if(rank == root)
   //printf(" \nValue of Pi with intervals %d is :: %f\n",no_interval,pi);

 



//printf("%s %d\n",hostname,data);



gettimeofday(&end,NULL); 
t3=t3+t2-t1;  
  	printf("%s\t%10.10f\n",hostname,( end.tv_usec  - start.tv_usec) / 1000000.0);
//printf("%10.10f\n", t3);
    /*.......Fianlizing MPI.......*/ 
  MPI_Finalize();
     return 0;
  }
 

