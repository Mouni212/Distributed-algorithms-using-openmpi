#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <math.h>

#define N (1024 * 1024 * 1)
#define n 4

int input[n];

int main(int argc, char *argv[])
{
  int numprocs, rank;
  struct timeval start, end;
  char hostname[256];
  int hostname_len;
int root=0;
int pi=0;
  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
  MPI_Get_processor_name(hostname,&hostname_len);
gettimeofday(&start,NULL);
  // Allocate a 10MiB buffer
  int buffer;

 if(rank == root)
       {
	buffer=rank+1;
         pi = pi + buffer;
        
	MPI_Recv(&buffer, 1, MPI_INT, 1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE); 
           pi = pi + buffer;
           printf(" \n%s : Value of sum is :: %d\n",hostname,pi);
         }  
else
{
	buffer=rank+1;
	pi = pi + buffer;
	if(rank+1 < numprocs)
	{
         MPI_Recv(&buffer, 1, MPI_INT, rank+1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE); 
	pi = pi + buffer;
}
	MPI_Send(&pi, 1, MPI_INT, rank-1, 1, MPI_COMM_WORLD);
	
           printf(" \n%s : Value of sum is :: %d\n",hostname,pi);
}
 
      if(rank == root)
   printf(" \nValue of sum is :: %d\n",pi);
gettimeofday(&end,NULL); 
  	printf("%s\t%10.10f\n",hostname,( end.tv_usec  - start.tv_usec) / 1000000.0);
  MPI_Finalize();
  return 0;
}
