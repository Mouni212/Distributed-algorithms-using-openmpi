   #include <stdio.h>
   #include <unistd.h>
   #include <cstdlib>
   #include <mpi.h>
#include <math.h>
   
   using namespace std;
   
   int main(int argc,char *argv[])
   {
     int root = 0,numprocs,rank,index;
     int no_interval;
     int destination,source;
     int dest_tag,source_tag;
     int iproc,interval;
	float t1,t2,t3;
     double my_pi,pi = 0.0,sum = 0.0,x = 0.0,h;
    
     MPI_Status status;
  struct timeval start, end;
  char hostname[256];
  int hostname_len;
     
   /* ..... MPI Intializing ......*/
 
     MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
  MPI_Get_processor_name(hostname,&hostname_len);
gettimeofday(&start,NULL);
  
int input[numprocs];
int numrow = 3;
int data,buffer;
buffer = 2;
if(rank == 0){
	printf(" \n Enter number of Intervals :: > ");
       scanf("%d", &no_interval);
	//for(int i=1;i<numprocs;i++)
		MPI_Send(&no_interval, numprocs, MPI_INT, rank+3, 1, MPI_COMM_WORLD);
		MPI_Send(&no_interval, numprocs, MPI_INT, rank+1, 1, MPI_COMM_WORLD);


}
else if(rank%numrow==0 && rank!=0){
	//for(int i=0;i<numprocs;i++)
	//	input[i]=0;
	if(rank-3>=0)
	MPI_Recv(&no_interval, numprocs, MPI_INT,rank-3, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	if(rank+3 < numprocs)
	MPI_Send(&no_interval,numprocs, MPI_INT, rank+3, 1, MPI_COMM_WORLD);
	if(rank+1 <numprocs)
	MPI_Send(&no_interval,numprocs, MPI_INT, rank+1, 1, MPI_COMM_WORLD);


}
else
{
	MPI_Recv(&no_interval, numprocs, MPI_INT,rank-1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	if(rank+1 < numprocs)
	MPI_Send(&no_interval,numprocs, MPI_INT, rank+1, 1, MPI_COMM_WORLD);

}

h = 1.0/(double)no_interval;
       sum = 0.0;
       for(interval = rank + 1; interval < no_interval;interval += numprocs)
        {
          x=h * ((double)interval - 0.5);
          sum = sum + (4.0 / (1.0 + x * x));
        }
        my_pi = h * sum;        


if(rank%numrow==0 || rank%numrow==1)
{
         pi = pi + my_pi;
         if(rank+1 < numprocs){
	MPI_Recv(&my_pi, 1, MPI_DOUBLE, rank+1, 1, MPI_COMM_WORLD, &status); 
	   pi=pi+my_pi;}
	if(rank+3 < numprocs && rank%numrow==0){
	MPI_Recv(&my_pi, 1, MPI_DOUBLE, rank+3, 1, MPI_COMM_WORLD, &status); 
           pi = pi + my_pi;}
	if(rank%numrow==0)
	MPI_Send(&pi, 1, MPI_DOUBLE, (rank-3), 1, MPI_COMM_WORLD);
	else
	MPI_Send(&pi, 1, MPI_DOUBLE, (rank-1), 1, MPI_COMM_WORLD);
printf("%s\t",hostname);
		printf("%f ",pi);
printf("\n");
}
else{
		
	MPI_Send(&my_pi, 1, MPI_DOUBLE, (rank-1), 1, MPI_COMM_WORLD);

printf("%s\t",hostname);
		printf("%f ",my_pi);
printf("\n");
    }   
 
      if(rank == root)
   printf(" \nValue of Pi with intervals %d is :: %f\n",no_interval,pi);

 



if(rank==0)
	printf("%f\n",pi);
gettimeofday(&end,NULL); 
t3=t3+t2-t1;  
  	printf("%s\t%10.10f\n",hostname,( end.tv_usec  - start.tv_usec) / 1000000.0);

    /*.......Fianlizing MPI.......*/ 
  MPI_Finalize();
     return 0;
  }
 

