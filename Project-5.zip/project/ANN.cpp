   #include <stdio.h>
   #include <unistd.h>
   #include <cstdlib>
   #include <mpi.h>
   
   using namespace std;
   
   int main(int argc,char *argv[])
   {
     int root = 0,numprocs,rank,index;
     int no_interval;
     int destination,source;
     int dest_tag,source_tag;
     int iproc,interval;
	float t1,t2,t3;
     double my_pi,pi = 0.0,sum = 0.0,x = 0.0,h;
    
     MPI_Status status;
  struct timeval start, end;
  char hostname[256];
  int hostname_len;
     
   /* ..... MPI Intializing ......*/
 
     MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
  MPI_Get_processor_name(hostname,&hostname_len);
gettimeofday(&start,NULL);
  
int input[numprocs];
int data,buffer;








gettimeofday(&end,NULL); 
t3=t3+t2-t1;  
  	printf("%s\t%10.10f\n",hostname,( end.tv_usec  - start.tv_usec) / 1000000.0);
printf("%10.10f\n", t3);
    /*.......Fianlizing MPI.......*/ 
  MPI_Finalize();
     return 0;
  }
 

