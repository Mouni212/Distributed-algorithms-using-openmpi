   #include <stdio.h>
   #include <unistd.h>
   #include <cstdlib>
   #include <mpi.h>
   
   using namespace std;
   
   int main(int argc,char *argv[])
   {
     int root = 0,numprocs,rank,index;
     int no_interval;
     int destination,source;
     int dest_tag,source_tag;
     int iproc,interval;
	float t1,t2,t3;
     int my_pi=0,pi = 0;
    
     MPI_Status status;
  struct timeval start, end;
  char hostname[256];
  int hostname_len;
     
   /* ..... MPI Intializing ......*/
 
     MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
  MPI_Get_processor_name(hostname,&hostname_len);
  
      


   
 

gettimeofday(&start,NULL); 
if(rank >= root && rank<=((numprocs-3)/2))
       {
	my_pi=rank+1;
         pi = pi + my_pi;
         if(2*rank+1 < numprocs)
	MPI_Recv(&my_pi, 1, MPI_DOUBLE, 2*rank+1, 1, MPI_COMM_WORLD, &status); 
	   pi=pi+my_pi;
	if(2*rank+2 < numprocs)
	MPI_Recv(&my_pi, 1, MPI_DOUBLE, 2*rank+2, 1, MPI_COMM_WORLD, &status); 
           pi = pi + my_pi;
           MPI_Send(&pi, 1, MPI_INT, (rank-1)/2, 1, MPI_COMM_WORLD);
	printf(" \n%s :: %d\n",hostname,pi);
         }  
else
        {
	my_pi = rank+1;
	MPI_Send(&my_pi, 1, MPI_INT, (rank-1)/2, 1, MPI_COMM_WORLD);
		printf(" \n%s :: %d\n",hostname,my_pi);
           }
 
         
 
      if(rank == root)
   printf(" \nValue of sum is :: %d\n",pi);
gettimeofday(&end,NULL); 
 
 
 	printf("%s\t%10.10f\n",hostname,( end.tv_usec  - start.tv_usec) / 1000000.0);
    /*.......Fianlizing MPI.......*/ 
  MPI_Finalize();
     return 0;
  }
 

