#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

#define N (1024 * 1024 * 1)

int global;

int main(int argc, char *argv[])
{
  int size, rank;
  struct timeval start, end;
  char hostname[256];
  int hostname_len;

  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  MPI_Get_processor_name(hostname,&hostname_len);

  // Allocate a 10MiB buffer
  char *buffer = malloc(sizeof(char) * N);

  // Communicate along the ring
  if (rank == 0) {
        global =4;

  } else {
       	printf("%d %d\n",rank,global);
  }

  MPI_Finalize();
  return 0;
}
