#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <math.h>

#define N (1024 * 1024 * 1)
#define n 4

int input[n][n];

int main(int argc, char *argv[])
{
  int size, rank;
  struct timeval start, end;
  char hostname[256];
  int hostname_len;

  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  MPI_Get_processor_name(hostname,&hostname_len);

  // Allocate a 10MiB buffer
  int buffer;

if(rank == 0){
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++)
		input[i][j] = i+j+1;
	}
}
if(rank%n==0)
{
	int p=2;
	int rank1=rank;

	while(p<=n){
		if(rank < n/p+rank1){
		       	MPI_Recv(&buffer, sizeof(int), MPI_BYTE, rank+(n/p)+rank1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			input[rank1][rank%n] += buffer;
		}
		else if(rank < (n/p)*2){
			MPI_Send(&input[rank1][rank%n], sizeof(int), MPI_BYTE, (rank-(n/p)+rank1), 1, MPI_COMM_WORLD);	
		}		
		p= p*2;		
		MPI_Barrier(MPI_COMM_WORLD);
	}

	printf("%d %d\n",rank1,input[rank1%n][0]);
	if(rank1!=(n-1)*n)
		MPI_Send(&input[rank1][0], sizeof(int), MPI_BYTE, (n-1)*n, 1, MPI_COMM_WORLD);	

}
if(rank==(n-1)*n)
{
	int p=2;
	
	while(p<=n){
		// 0 - 4 - 8 - 16
		if(rank < n/p){
		       	MPI_Recv(&buffer, sizeof(int), MPI_BYTE, rank+(n/p), 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			input[rank%n] += buffer;
		}
		else if(rank < (n/p)*2){
			MPI_Send(&input[rank%n], sizeof(int), MPI_BYTE, (rank-(n/p)), 1, MPI_COMM_WORLD);	
		}		
		p= p*2;		
		MPI_Barrier(MPI_COMM_WORLD);
	}

	printf("%d %d\n",rank,input[rank%n]);
}
int p=2;

	while(p<=n){
		
		if(rank < n/p){
		       	MPI_Recv(&buffer, sizeof(int), MPI_BYTE, rank+(n/p), 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			input[rank%n] += buffer;
		}
		else if(rank < (n/p)*2){
			MPI_Send(&input[rank%n], sizeof(int), MPI_BYTE, (rank-(n/p)), 1, MPI_COMM_WORLD);	
		}		
		p= p*2;		
		MPI_Barrier(MPI_COMM_WORLD);
	}

	printf("%d %d\n",rank,input[rank%n]);

  MPI_Finalize();
  return 0;
}
