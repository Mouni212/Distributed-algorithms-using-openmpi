#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <mpi.h>
  
 int main(int argc,char *argv[])
 {
   int root = 0,numprocs,myrank,index;
   int no_interval;
   int destination,source;
   int dest_tag,source_tag;
   int iproc,interval;
   float t1,t2,t3;
   double my_pi,pi = 0.0,sum = 0.0,x = 0.0,h;
 
   MPI_Status status;
    struct timeval start, end;
    char hostname[256];
    int hostname_len;
  
 /* ..... MPI Intializing ......*/

   MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
    MPI_Get_processor_name(hostname,&hostname_len);
    gettimeofday(&start,NULL);


   if(myrank == root)
    {
     printf(" \n Enter number of Intervals :: > ");
     scanf("%d", &no_interval);
   }


      /* Send no. of intervals to all...  */
         // for(iproc = 1 ; iproc < numprocs ; iproc++)
         // {
         //  destination = iproc;
         //  dest_tag = 0;
         //    t1 = MPI_Wtime();
 
         //    MPI_Send(&no_interval, sizeof(int), MPI_INT, destination, dest_tag, MPI_COMM_WORLD);
         //  //MPI_COMM_WORLD.Send(&no_interval,1,MPI::INT,destination,dest_tag);
         // }
  if(myrank==0)
  {
    MPI_Send(&no_interval, 1, MPI_DOUBLE, myrank+1, 0, MPI_COMM_WORLD);
  }
  else if(myrank == 1)
  {
    MPI_Recv(&no_interval, 1, MPI_DOUBLE, myrank-1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
  }

  if(myrank==0 || myrank==1)
  {
    MPI_Send(&no_interval, 1, MPI_DOUBLE, myrank+2, 0, MPI_COMM_WORLD);
  }
  else if(myrank == 2 || myrank==3)
  {
    MPI_Recv(&no_interval, 1, MPI_DOUBLE, myrank-2, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
  }
 

  if(myrank==0 || myrank==1 || myrank==2 || myrank==3)
  {
    MPI_Send(&no_interval, 1, MPI_DOUBLE, myrank+4, 0, MPI_COMM_WORLD);
  }
  else
  {
    MPI_Recv(&no_interval, 1, MPI_DOUBLE, myrank-4, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
  }              
   //    }
   // else
   //   {
   //       source = root;
   //       source_tag = 0;
   //     //MPI_COMM_WORLD.Recv(&no_interval,1,MPI::INT,source,source_tag,status);
   //      MPI_Recv(&no_interval, 1, MPI_INT, source, source_tag, MPI_COMM_WORLD, &status); 
   //      t2 = MPI_Wtime(); 
   //      t3=t2-t1;    
   //    }         
       
     h = 1.0/(double)no_interval;
     sum = 0.0;
     for(interval = myrank + 1; interval < no_interval;interval += numprocs)
      {
        x=h * ((double)interval - 0.5);
        sum = sum + (4.0 / (1.0 + x * x));
      }
      my_pi = h * sum;           

    /* Collect the pi values .....*/


  //   if (myrank != root) {
  //   // If we are not the root process, send our data to0
  //       MPI_Send(&my_pi, 1, MPI_DOUBLE, root, 0, MPI_COMM_WORLD);
  // } else {
  //   // If we are a receiver process, receive the data from the root
  //   int i;
  //   pi = pi + my_pi;
  //   for (i = 1; i < numprocs; i++) 
  //   {
  //     MPI_Recv(&my_pi, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
  //     pi = pi + my_pi;
  //   }
  // }


  if(myrank==4 || myrank==5|| myrank==6 || myrank==7)
  {
    MPI_Send(&my_pi, 1, MPI_DOUBLE, myrank-4, 0, MPI_COMM_WORLD);
  }
  else
  {
    pi = pi+my_pi;
    MPI_Recv(&my_pi, 1, MPI_DOUBLE, myrank+4, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    my_pi = pi + my_pi;
  }

  if(myrank==2 || myrank==3)
  {
    MPI_Send(&my_pi, 1, MPI_DOUBLE, myrank-2, 0, MPI_COMM_WORLD);
  }
  else if(myrank == 1 || myrank==0)
  {
    pi = pi+my_pi;
    MPI_Recv(&my_pi, 1, MPI_DOUBLE, myrank+2, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    my_pi = pi + my_pi; 
  }

  if(myrank==1)
  {
    MPI_Send(&my_pi, 1, MPI_DOUBLE, myrank-1, 0, MPI_COMM_WORLD);
  }
  else if(myrank == 0)
  {
    pi = pi+my_pi;
    MPI_Recv(&my_pi, 1, MPI_DOUBLE, myrank+1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    // pi = pi + my_pi;
    // *data = *data + (int)num;
    // printf("%d\n",*((int*)data));
  }


    if(myrank == root)
        printf(" \nValue of Pi with intervals %d is :: %f\n",no_interval,pi);

    gettimeofday(&end,NULL);
    t3=t3+t2-t1; 
     printf("%s\t%10.10f\n",hostname,( end.tv_usec  - start.tv_usec) / 1000000.0);
     printf("%10.10f\n", t3);
    /*.......Fianlizing MPI.......*/
    MPI_Finalize();
    return 0;
}