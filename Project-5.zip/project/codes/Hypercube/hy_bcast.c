#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <assert.h>



void HY_Bcast(void* data, int count, MPI_Datatype datatype, int root,
              MPI_Comm communicator) {
  int world_rank;
  MPI_Comm_rank(communicator, &world_rank);
  int world_size;
  MPI_Comm_size(communicator, &world_size);

  if(world_rank==0)
  {
  	MPI_Send(data, count, datatype, world_rank+1, 0, communicator);
  }
  else if(world_rank == 1)
  {
  	MPI_Recv(data, count, datatype, world_rank-1, 0, communicator, MPI_STATUS_IGNORE);
  }

  if(world_rank==0 || world_rank==1)
  {
  	MPI_Send(data, count, datatype, world_rank+2, 0, communicator);
  }
  else if(world_rank == 2 || world_rank==3)
  {
  	MPI_Recv(data, count, datatype, world_rank-2, 0, communicator, MPI_STATUS_IGNORE);
  }
 

  if(world_rank==0 || world_rank==1 || world_rank==2 || world_rank==3)
  {
  	MPI_Send(data, count, datatype, world_rank+4, 0, communicator);
  }
  else
  {
  	MPI_Recv(data, count, datatype, world_rank-4, 0, communicator, MPI_STATUS_IGNORE);
  }
 }

int main(int argc, char** argv) {
  if (argc != 3) {
    fprintf(stderr, "Usage: ./naive elements trials\n");
    exit(1);
  }

  int elements = atoi(argv[1]);
  int trials = atoi(argv[2]);

  MPI_Init(NULL, NULL);

  int world_rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
	int world_size;
  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

  double total_time = 0.0;
  int i;

  int* data = (int*)malloc(sizeof(int) * elements);
  assert(data != NULL);

  for(i=0; i<elements; ++i)
  {
  	*(data+i) = 10;
  }

  for (i = 0; i < trials; i++) {
    //MPI_Barrier(MPI_COMM_WORLD);
    total_time -= MPI_Wtime();
    HY_Bcast(data, elements, MPI_INT, 0, MPI_COMM_WORLD);
    //MPI_Barrier(MPI_COMM_WORLD);
    total_time += MPI_Wtime();
  }

  if (world_rank != 0) {
    printf("Data size = %d, Trials = %d\n", elements * (int)sizeof(int),
           trials);
    printf("Avg broadcast time taken by this program = %lf\n", total_time / trials);
  }

  free(data);
  MPI_Finalize();
}
