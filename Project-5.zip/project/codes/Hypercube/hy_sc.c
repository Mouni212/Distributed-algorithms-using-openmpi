#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <assert.h>


int main(int argc, char** argv) {
  if (argc != 3) {
    fprintf(stderr, "Usage: ./naive elements trials\n");
    exit(1);
  }

  int elements = atoi(argv[1]);
  int trials = atoi(argv[2]);

  MPI_Init(NULL, NULL);

  int world_rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
  int world_size;
  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

  double total_time = 0.0;
  int i;
  int* data = (int*)malloc(sizeof(int) * elements);
  assert(data != NULL);

  if(world_rank==0)
  {
    for(i=0; i<elements; ++i)
    {
      data[i] = 10;
    }
}

  // for (i = 0; i < trials; i++) {
  //   //MPI_Barrier(MPI_COMM_WORLD);
  //   
  //   HY_Bcast(data, elements, MPI_INT, 0, MPI_COMM_WORLD);
  //   //MPI_Barrier(MPI_COMM_WORLD);
  //   
  // }

total_time -= MPI_Wtime();


  if(world_rank==0)
  {
    for(int i=0; i<8;++i)
      printf("%d",data[i]);
    for(int i=0; i<4;++i)
    MPI_Send(&data[i+4], 1, MPI_INT, 4, 0, MPI_COMM_WORLD);
  }
  else if(world_rank == 4)
  {
    for(int i=0; i<4;++i)
    MPI_Recv(&data[i], 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
  }

  if(world_rank==0 || world_rank==4)
  {
    for(int i=0; i<2;++i)
    MPI_Send(&data[i+2], 1, MPI_INT, world_rank+2, 1, MPI_COMM_WORLD);
  }
  else if(world_rank == 2 || world_rank==6)
  {
    for(int i=0; i<2;++i)
    MPI_Recv(&data[i], 1, MPI_INT, world_rank-2, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
  }
 

  if(world_rank==0 || world_rank==2 || world_rank==4 || world_rank==6)
  {
    MPI_Send(&data[1], 1, MPI_INT, world_rank+1, 1, MPI_COMM_WORLD);
  }
  else
  {
    MPI_Recv(&data[0], 1, MPI_INT, world_rank-1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
  }
  total_time += MPI_Wtime();

  printf("data: %d wr %d\n",(int)data[0],world_rank);

  if (world_rank != 0) {
    printf("Data size = %d, Trials = %d\n", elements * (int)sizeof(int),
           trials);
    printf("Avg broadcast time taken by this program = %lf\n", total_time/* / trials*/);
  }

  free(data);
  MPI_Finalize();
}
