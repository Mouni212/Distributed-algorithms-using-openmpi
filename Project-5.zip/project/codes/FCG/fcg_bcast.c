#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <assert.h>

int main(int argc, char** argv) {
  if (argc != 3) {
    fprintf(stderr, "Usage: ./naive elements trials\n");
    exit(1);
  }

  int elements = atoi(argv[1]);
  int trials = atoi(argv[2]);

  MPI_Init(NULL, NULL);

  int world_rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

  double total_time = 0.0;
  int i;

  int* data = (int*)malloc(sizeof(int) * elements);
  assert(data != NULL);

  for(i=0; i<elements; ++i)
  {
  	*(data+i) = i;
  }

  for (i = 0; i < trials; i++) {
    //MPI_Barrier(MPI_COMM_WORLD);
    total_time -= MPI_Wtime();
    MPI_Bcast(data, elements, MPI_INT, 0, MPI_COMM_WORLD);
    //MPI_Barrier(MPI_COMM_WORLD);
    total_time += MPI_Wtime();
  }

  if (world_rank == 1||world_rank==2||world_rank==3) {
    printf("wr = %d,Data size = %d, Trials = %d\n", world_rank,elements * (int)sizeof(int),
           trials);
    printf("Avg broadcast time taken by this program = %lf\n", total_time / trials);
  }

  free(data);
  MPI_Finalize();
}
