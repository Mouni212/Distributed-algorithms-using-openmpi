
#include <iomanip>
#include "Master.h"


Master::Master(int pid, std::string pname, Polynomial& polynomial)
        : polynomial(polynomial), finished(false), generation(0), shouldPrintHeader(true) {
    this->pid = pid;
    this->pname = std::move(pname);
    for(int& i : this->buffer) i = 0;

}




void Master::printHeader() {
    //std::lock_guard<std::mutex> lock(mutex_stdout);
    std::cout << "==============================================================================================================" << std::endl;
    std::cout << "Generation: " << generation << std::endl;
    std::cout << std::fixed << std::setw(14) << "Worker Id |"
    		  << std::fixed << std::setw(14) << "Fitness |"
              << std::fixed << std::setw(14) << "Root 	\n";
              
    std::cout << "--------------------------------------------------------------------------------------------------------------" << std::endl;
}


void Master::printReport(int id, double *summary, std::string note) {
    //std::lock_guard<std::mutex> lock(mutex_stdout);
    std::cout << std::scientific << std::setw(11) << std::setprecision(3) << id << "  |"
    		  << std::scientific << std::setw(11) << std::setprecision(3) << summary[Population::SUM_NDX_MIN] <<" |"
              << std::scientific << std::setw(11) << std::setprecision(3) << summary[Population::SUM_NDX_REAL] << " + " <<summary[Population::SUM_NDX_IMAG]<<"i \n "  ;            
              
}


int Master::mainProcedure(){
    auto startTime  = std::chrono::high_resolution_clock::now();
    auto epochStart = startTime;

    std::complex<double> migration_buf[MIGRATION_LIMIT];

    std::cout << "starting" << std::endl;

    int code = NOTHING;

    std::complex<double> final;
    int finder = -1;
    double summary[Population::SUM_SIZE];

    printHeader();

    //get initial population stats
    for (int i = 1; i < networkSize; i++){
        MPI_Recv(summary, Population::SUM_SIZE, MPI_DOUBLE, i, TAG_SUMMARY, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printReport(i, summary," ==> Initial population");
    }

    code = CONTINUE;
    generation++;

    while (true){

        epochStart = std::chrono::system_clock::now();

        //wait for workers to finish their evolutions
        MPI_Barrier(MPI_COMM_WORLD);

        if (finished) code = STOP;

        //allow workers to continue
        MPI_Bcast(&code, 1, MPI_INTEGER, MASTER_PID, MPI_COMM_WORLD);

        if (finished) break;

        printHeader();
//        std::cout << "starting at master" << std::endl;

        for(int wid = 1; wid < networkSize; wid++){

            //allow process wid to send report and other information to master
            MPI_Send(&code, 1, MPI_INTEGER, wid, TAG_QUEUED_UP, MPI_COMM_WORLD);

            //receive status from worker
            MPI_Recv(&code, 1, MPI_INTEGER, wid, TAG_STATUS_UPDATE, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            if(code == COMPLETE || code == COMPLETE_MORE) {
                finished = true;
            }
            if(code == COMPLETE_MORE) {
                MPI_Recv(&final, 1, MPI_DOUBLE_COMPLEX, wid, TAG_FINAL, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                finder = wid;
            }


            //get summary of progress
            MPI_Recv(summary, Population::SUM_SIZE, MPI_DOUBLE, wid, TAG_SUMMARY, MPI_COMM_WORLD, MPI_STATUS_IGNORE);


            //print summary
            if (code == CONVERGED) printReport(wid, summary, " ==> Convergence");
            else printReport(wid, summary);

        }

        std::chrono::duration<double, std::milli> epochDuration = std::chrono::high_resolution_clock::now() - epochStart;

        std::cout << std::defaultfloat << std::setprecision(10)  << "Epoch during: " << 0.001 * epochDuration.count() << "s" << std::endl;


        /*//migration and integration
        for (int i = 1; i < networkSize; i++){
            MPI_Bcast(&migration_buf, MIGRATION_LIMIT, MPI_DOUBLE_COMPLEX, i, MPI_COMM_WORLD);
        }*/

        generation++;
    }

    std::cout << "\n\n";
    std::cout << std::defaultfloat << "f(x) = " << polynomial << "\n\n";

    std::complex<double> finalResults[networkSize];
    for (int i = 1; i < networkSize; i++){
        MPI_Recv(&finalResults[i], 1, MPI_DOUBLE_COMPLEX, i, TAG_FINAL, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        std::cout << "Worker (" << i << ") best result = " << finalResults[i].real() << " + " << finalResults[i].imag() << "i ==> " << std::abs(polynomial(finalResults[i])) << std::endl;
    }


    std::cout << "\n";
    std::cout << std::fixed
              << "f(x) = 0 when x ~= " << final.real() << " + " << final.imag() << "i"
              << " with the fitness of " << std::abs(polynomial(final)) << std::endl;
    std::cout << "found by " << finder << std::endl;

    std::chrono::duration<double, std::milli> duration = std::chrono::high_resolution_clock::now() - startTime;

    std::cout << std::fixed << std::setprecision(10) << "time elapsed: " << 0.001 * duration.count() << "s" << std::endl;


}


