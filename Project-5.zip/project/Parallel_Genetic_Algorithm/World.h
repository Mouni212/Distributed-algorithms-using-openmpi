#ifndef POLYNOMIAL_ROOT_FINDING_PGA_WORLD_H
#define POLYNOMIAL_ROOT_FINDING_PGA_WORLD_H

#include "World/Individual.h"
#include "World/Population.h"


#include <complex>
#include <ctime>

class Population;
class Individual;
class Polynomial;





#endif //POLYNOMIAL_ROOT_FINDING_PGA_WORLD_H
