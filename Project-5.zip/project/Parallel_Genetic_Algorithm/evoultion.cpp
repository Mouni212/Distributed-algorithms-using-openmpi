//Elitism - Selection and Evolve


void Population::select(Individual* parents[2]) {
    
    unsigned long pop_half = _combined_population_size/2;


   
        do {

            //get random number [0, pop_half] to pick from population
    		double num1 = rand() % pop_half;
    		double num2 = rand() % pop_half;



        } while (num1 == num2);


    //copy parents for higher scoped function
    parents[0] = _combined_population[num1];
    parents[1] = _combined_population[num]2;


}



Individual* Population::select() {
    Individual *ret= nullptr; //ret := the returned parent

    unsigned long pop_half = _combined_population_size/2;


    //get random number [0, pop_half] to pick from population
    double num = rand % pop_half;

    ret = _combined_population[num];


    return ret;
}

Population::status Population::evolve(){

    status status = NOT_FOUND;

    //sort population
    sort();

    //check for a root
    if (checkSolution()) return FOUND;

    //check & handle convergence
    if (checkChromosomeConvergence()) {
        status = CONVERGED;
        handleConvergence();
    }



    Population new_generation(_fitness_function, 0);
	unsigned long children = 0.9*_population_size;
	unsigned long elite = _population_size - children;
	for (unsigned long i = 0; i < elite; i++)
	new_generation.push_back (_population[i]);
	
	
    for (unsigned long i = elite; i < _population_size/2; i++) {
        Individual* parents[2];
        select(parents);

        Individual offspring[2];
        crossover(offspring, parents);    

        mutate(offspring[0]);
        mutate(offspring[1]);

        new_generation._population.push_back(offspring[0]);
        new_generation._population.push_back(offspring[1]);

    }

   


    fitPopulation(new_generation);    

    _generation++;

    //_migrated_population.empty();
    _combined_population.empty();
    for (int i = 0; i < _population_size; i++){
        _combined_population[i] = &_population[i];
    }

    _combined_population_size = _population_size;

    return status;
}





// Roulette Wheel (Selection)

void Population::select(Individual* parents[2]) {
    Individual *ret[2] = {nullptr, nullptr}; //ret    := used to hold ret values until end to assign parents
    Individual *not_me = nullptr;              //not_me := used to avoid selecting same member twice

    unsigned long pop_cap = _combined_population_size;

    

    auto inverse = new double[pop_cap];    //probability[i] = fitness(i) / total_i
    auto probability = new double[pop_cap];    //accumulated[i] = accumulated[i - 1] + probability[i]
    
   

    //calculating probability
    double totalFitness = 0;
    for (int i = 0; i < pop_cap; i++) inverse[i] = 1/_combined_population[i]->getFitness() , totaliFitness + = inverse[i];
    for (int i = 0; i < pop_cap; i++) probability[i] = inverse[i] / totalFitness;

    //for each parent (2)
    for (auto &ndx : ret) {

        //do while the parents are equal to each other
        do {

            //get random number [0, 1] from uniform distribution to pick from population
            double num = rng::getRealUniformDist(0.0, 1.0);

           //pick from population by setting i where num <= accumulated[i]
		    unsigned long i = 0;
		    while (i < pop_cap && num > probability[i++]) { /*do nothing*/ }

            //if the index we picked was from
            ndx = _combined_population[--i];

        } while (ndx == not_me);


        //to make sure parents are not equal
        not_me = ret[0];
    }

    //copy parents for higher scoped function
    parents[0] = ret[0];
    parents[1] = ret[1];


    //deleting
    delete[] probability;
    delete[] accumulated;

}


Individual* Population::select() {
    Individual *ret= nullptr; //ret := the returned parent

    unsigned long pop_cap = _combined_population_size;

    

    auto inverse = new double[pop_cap];    //probability[i] = fitness(i) / total_i
    auto probability = new double[pop_cap];    //accumulated[i] = accumulated[i - 1] + probability[i]
    
   

    //calculating probability
    double totalFitness = 0;
    for (int i = 0; i < pop_cap; i++) inverse[i] = 1/_combined_population[i]->getFitness() , totaliFitness + = inverse[i];
    for (int i = 0; i < pop_cap; i++) probability[i] = inverse[i] / totalFitness;


    //get random number [0, 1] from uniform distribution to pick from population
    double num = rng::getRealUniformDist(0.0, 1.0);

    //pick from population by setting i where num <= accumulated[i]
    unsigned long i = 0;
    while (i < pop_cap && num > probability[i++]) { /*do nothing*/ }

    //if the index we picked was from
    ret = _combined_population[--i];

    //deleting
    delete[] probability;
    delete[] inverse;

    return ret;
}










// Crossover as a third of parents and corresponding Evolve

void Population::crossover(Individual offspring[2], Individual* parents[2]) {

    Individual ret[2];

    std::complex<double> p1 = parents[0]->getChromosome();
    std::complex<double> p2 = parents[1]->getChromosome();

   

    double real_third1 = (p1.real()+ 2*p2.real())/3;   
    double imag_third1 = (p1.imag()+ 2*p2.imag())/3;
    double real_third2 = (2*p1.real()+ p2.real())/3;   
    double imag_third2 = (2*p1.imag()+ p2.imag())/3;
    


    //geofencing
    ret[0] = Individual(real_third1 , imag_third1);
    ret[1] = Individual(real_third2 , imag_third2);

    ret[0].setFitness(_fitness_function(ret[0]));
    ret[1].setFitness(_fitness_function(ret[1]));
   
    offspring[0] = ret[0];
    offspring[1] = ret[1];


}

