   #include <stdio.h>
   #include<math.h>
   #include <unistd.h>
   #include <cstdlib>
   #include <mpi.h>
   
   using namespace std;
   
   int main(int argc,char *argv[])
   {
     int root = 0,numprocs,rank,index;
     int no_interval;
     int destination,source;
     int dest_tag,source_tag;
     int iproc,interval;
	float t1,t2,t3;
     double my_pi,pi = 0.0,sum = 0.0,x = 0.0,h;
    
     MPI_Status status;
  struct timeval start, end;
  char hostname[256];
  int hostname_len;
     
   /* ..... MPI Intializing ......*/
 
     MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
  MPI_Get_processor_name(hostname,&hostname_len);
gettimeofday(&start,NULL);
  
int input[numprocs];
int data;

if(rank == 0){
	int buffer;
	input[0]=1;
	for(int i=1;i<=numprocs/2;i++){
		MPI_Recv(&buffer, 1, MPI_INT, (1), 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		printf("%s %d\n",hostname,buffer);
		input[i]=buffer;
	}
	for(int i=numprocs/2+1;i<numprocs;i++){
		MPI_Recv(&buffer, 1, MPI_INT, (2), 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		printf("%s %d\n",hostname,buffer);
		input[i]=buffer;
	}
	
}
else{
	int i,buffer;
	//input[rank]=rank+1;
	buffer=rank+1;
	int k = log2(rank+1);
	k = pow(2,k);
	int itr = (numprocs+1)/(2*k);
	printf("iterationnumber %s %d\n",hostname,itr);
	for(i=0;i<itr;i++){
			MPI_Send(&buffer, 1, MPI_INT, (rank-1)/2, 1, MPI_COMM_WORLD);
			if(2*rank+1 < numprocs){
				MPI_Recv(&buffer, 1, MPI_INT, 2*rank+1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
				MPI_Send(&buffer, 1, MPI_INT, (rank-1)/2, 1, MPI_COMM_WORLD);
				printf("%s %d\n",hostname,buffer);
			}
			if(2*rank+2 < numprocs){
				MPI_Recv(&buffer, 1, MPI_INT, 2*rank+2, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
				MPI_Send(&buffer, 1, MPI_INT, (rank-1)/2, 1, MPI_COMM_WORLD);
				printf("%s %d\n",hostname,buffer);
			}
	}
}
if(rank == 0){
	for(int i=0;i<numprocs;i++)
		printf("%d\t%d\n",i,input[i]);
}


gettimeofday(&end,NULL); 

  	printf("%s\t%10.10f\n",hostname,( end.tv_usec  - start.tv_usec) / 1000000.0);

    /*.......Fianlizing MPI.......*/ 
  MPI_Finalize();
     return 0;
  }
 

